# Encrypt:
zip -r skeys.zip skeys/
openssl enc -aes-256-cbc -salt -in skeys.zip -out skeys.zip.enc -k [password]
dd if=/dev/urandom of=skeys.zip bs=512 count=10
rm skeys.zip

# Decrypt:
openssl enc -aes-256-cbc -d -in skeys.zip.enc -out skeys.zip -k [password]
unzip skeys.zip -d /skeys2
rm -rf skeys


