Used https://dsociety.io/util to get unique 8 Char Reference

# 1. Members

Full Members List @
https://docs.google.com/spreadsheets/d/1gWFTF9m_goP1IDeSbpC5RvrP30B1yHw-zeFKJJz4BwY

## Phil Lewis
MIE17V8P

## Yuki Oishi
aka Yuta
KXM4WVSF

## Jo Allum
N8U72696

## Oscar Hong
aka Oscar West
Z36CTN7X

## Mark Byers
TPMTPQJJ

## Ha Nguyen
WWSLICL5

# 2. Create X.509 Certification for ECC identification and use for management & voting roles etc

To get latest openSSL on MacOS that supports 
## 2.1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

## 2.2. brew install openssl

## 2.3.
openssl genpkey -algorithm ed25519 \
-out member-mark-byers-TPMTPQJJ.key

## 2.4.
openssl req -new \
-key member-mark-byers-TPMTPQJJ.key
-out member-mark-byers-TPMTPQJJ.csr

// Mark Byers (TPMTPQJJ)
C = AU
ST = NSW
L = Sydney
O = Eastern Cardano Council
OU = Operations
CN = mark.byers.tpmtpqjj.council.eastern.council

## 2.5 Upload the .csr file to your folder in the members folder.
!!! Do not upload the .key file, as you need to keep it private from everyone - including other ECC members.

## 2.6 Storing Key
If you are already have a process for storing sensitive data then ignore this then please document it and upload it as file to your folder in the /members area.

Else, suggest:

2.6.1 Get a good quality USB
2.6.2. Using your OS (eg MacOS) erase it with the highest level.
2.6.3. Create a /data/keys folder
2.6.4. Run this command in your terminal:
openssl enc -aes-256-cbc -d -in member-mark-byers-TPMTPQJJ.key -out member-mark-byers-TPMTPQJJ.key.enc -k password
* replace "member-mark-byers-TPMTPQJJ" with your full-name-id and set your password (14 char minimum)
